import SEO from '../../components/Blog/SEO';

const Work = () => (
  <>
    <SEO
        title="Work | Small Sided"
        description="WORK DESCRIPTION. Learn about Small Sided and our mission to transform soccer training."
        type="website"
        url="/about"
      />
    <h2>Work</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
  </>
);

export default Work;
